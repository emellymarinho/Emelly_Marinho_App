package com.example.emelly_prova_final;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity /*(tableName = "users")*/
public class Musica {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "musica")
    public String musica;

    @ColumnInfo(name = "genero")
    public String genero;

    @ColumnInfo(name = "artista")
    public String artista;

    @ColumnInfo(name = "album")
    public String album;

    @ColumnInfo(name = "integrante")
    public String integrante;


}


