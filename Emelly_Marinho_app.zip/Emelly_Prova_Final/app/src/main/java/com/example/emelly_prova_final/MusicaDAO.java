package com.example.emelly_prova_final;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MusicaDAO {

        @Query("SELECT * FROM Musica")
        List<Musica> listar();

        @Insert
        void insert(Musica... musicas);

        @Delete
        void delete(Musica musicas);
  /*    public void deleteUsers(User... users);
*/
}

