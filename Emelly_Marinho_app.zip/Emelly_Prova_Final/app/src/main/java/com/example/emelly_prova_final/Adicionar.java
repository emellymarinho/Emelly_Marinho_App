package com.example.emelly_prova_final;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Adicionar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar);
    }

    public void Salvar(View view) {
        EditText txtMusica = findViewById(R.id.txtMusica);
        EditText txtGenero = findViewById(R.id.txtGenero);

        EditText txtArtista = findViewById(R.id.txtArtista);
        EditText txtAlbum = findViewById(R.id.txtAlbum);
        EditText txtIntegrante = findViewById(R.id.txtIntegrante);

        //Campos adicionais


       Musica m = new Musica();
        m.musica = txtMusica.getText().toString();
        m.genero = txtGenero.getText().toString();

        m.artista = txtArtista.getText().toString();
        m.album = txtAlbum.getText().toString();
        m.integrante = txtIntegrante.getText().toString();




        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "musicas").build();
                    MusicaDAO dao = db.musicaDAO();


                    dao.insert(m);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder builder = new AlertDialog.Builder(Adicionar.this);
                            builder.setMessage("Salvo com sucesso");
                            builder.create().show();
                        }
                    });


                }
            }).start();


        }catch (Exception ex){
            ex.printStackTrace();
        }


    }

    public void Voltar(View view) {
        finish();
    }
}