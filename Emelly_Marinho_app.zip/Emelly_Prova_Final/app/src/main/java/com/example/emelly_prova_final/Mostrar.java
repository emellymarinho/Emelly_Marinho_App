package com.example.emelly_prova_final;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class Mostrar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);
    }

    public void Carregar(View view) {
        LinearLayout lnlMusicas = findViewById(R.id.lnlMusicas);
        lnlMusicas.removeAllViews();

        new Thread(new Runnable() {
            @Override
            public void run() {
                AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "musicas").build();
                MusicaDAO dao = db.musicaDAO();

                List<Musica> musicas = dao.listar();


                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (Musica m: musicas){

                            TextView t = new TextView(Mostrar.this);
                            t.setText(m.musica);

                            TextView g = new TextView(Mostrar.this);
                            g.setText(m.genero);

                            TextView a = new TextView(Mostrar.this);
                            a.setText(m.artista);

                            TextView b = new TextView(Mostrar.this);
                            b.setText(m.album);

                            TextView i = new TextView(Mostrar.this);
                            i.setText(m.integrante);



                            lnlMusicas.addView(t);
                            lnlMusicas.addView(g);

                            lnlMusicas.addView(a);
                            lnlMusicas.addView(b);
                            lnlMusicas.addView(i);


                        }
                    }
                });

            }

        }).start();
    }
    public void Voltar(View view) {
        finish();
    }
}